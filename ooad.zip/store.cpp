#include"store.h"
#include<iostream>
#include<fstream>
#include<ctime>
#include<time.h>
using namespace std;

store::store()
{
}

store::~store()
{
}

void store::record()
{
	int year, month, day;
	time_t now;
	struct tm nowsystem;
	now = time(NULL);
	localtime_s(&nowsystem, &now);
	year = nowsystem.tm_year + 1900;
	day = nowsystem.tm_mday;
	month = nowsystem.tm_mon;
	month++;
	

	ifstream fin;
	fin.open("bil.txt");
	char a[20];
	ofstream fout;
	fout.open("record.txt",ios::app);
	fout << day << "-" << month << "-" << year<<endl;
	while (!fin.eof())
	{
		fin.getline(a, 20);
		fout << a << endl;
	}
	fin.clear();
	fin.close();
	fout << endl;
	fout.close();

	
}