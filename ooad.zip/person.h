#pragma once

class person
{
public:
	person(char*,int );
	person();
	~person();
	char* get_name();
	char* get_type();
	int get_id();
	void set_name(char*);
	void set_type(char*);
	void set_id(int);
	int _length(char*);
	void copy(char*&, char*);

private:
	char* name;
	int id;

};

