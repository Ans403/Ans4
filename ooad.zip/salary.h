#pragma once

class salary
{
public:
	salary(long int=0);
	void set_sal(long int);
	long int get_sal();
	~salary();

private:
	long int sal;
};

