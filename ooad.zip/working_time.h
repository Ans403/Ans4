#pragma once

class work
{
public:
	work(char*);
	work();
	~work();
	void copy(char*&,char*);
	int length(char*);
	void set_time(char*);
	char* get_time();

private:
	char* time;
};

