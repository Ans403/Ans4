#include"waiter.h"

int waiter::length(char *arr)
{
	int i = 0;
	for (i; arr[i] != '\0'; i++)
	{
	}
	return i;
}

void waiter::copy(char *&arr, char *arr1)
{
	int n = 0;
	int l = length(arr1);
	arr = new char[l + 1];
	for (; n < l; n++)
	{
		arr[n] = arr1[n];
	}
	arr[l] = '\0';
}

waiter::waiter()
{

}

waiter::waiter(int total_no)
{
	total_waiters = total_no;
}

waiter::waiter(char* wor_t, long int sa, char* n, int id_) :salary(sa), work(wor_t)
{
	
	copy(name, n);
	id = id_;
}

void waiter::set_salary(long int sala)

{
	set_sal(sala);
}

void waiter::set__time(char* t)
{
	set_time(t);
}

long int waiter::get_salary()
{
	return get_sal();
}

char* waiter::get_working_time()
{
	return get_time();
}

void waiter::set_total(int t)
{
	total_waiters = t;
}

int waiter::get_total()
{
	return total_waiters;
}

waiter::~waiter()
{
}