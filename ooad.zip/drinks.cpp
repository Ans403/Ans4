#include"drinks.h"
#include<iostream>
#include<fstream>
using namespace std;

drink::drink(int w, int cd, int c) :pr(w,cd,c)
{

}

drink::~drink()
{
}

void drink::displayy()
{
	cout << " press1 for water\n press 2 for cold drink\n press 3 for coffee\n";
}

void drink::drinks()
{
	ofstream fout;
	fout.open("bil.txt", ios::app);
	int in = 0;
	int t = 0;
	t = pr.get_total();
	while (in != -1)
	{
		cin >> in;
		int p = 0;
		switch (in)
		{
		case 1:
			p = pr.get_wp();
			cout << "price:" << p<<endl;
			fout << "water\t\t" << p<<endl;
			break;
		case 2:
			p = pr.get_cdp();
			cout << "price:" << p << endl;
			fout << "cold drink\t\t" << p << endl;
			break;

		case 3:
			p = pr.get_cp();
			cout << "price:" << p << endl;
			fout << "coffee\t\t" << p << endl;
			break;
		case -1:
			break;
		default:
			cout << "invalid entry\n";
			break;
		}
		
		

		t = t + p;

	}
	pr.set_total(0);
	cout << "Total:" << t << endl;
	fout << "Total:" << t;
	
}