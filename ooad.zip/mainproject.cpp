#include"prices.h"
#include"food_items.h"
#include"bill.h"
#include"fast_foods.h"
#include"store.h"
#include"administrator.h"
#include"drinks.h"
#include<iostream>
using namespace std;

int main()
{


	int a = 0;

	while (a != -1)
	{
		cout << " 1 administrator \n 2 user\n -1 to exit\n";
		cin >> a;


			if (a == 2)
			{


				

				foods fo;



		while (fo.get_input() != -1)
			{
			fo.displayy();
			if (fo.get_input() == 1)
			{
				fast_food ff(120, 300, 100, 150, 50);
				ff.displayy();
			ff.fast();

		system("CLS");


			}

			if (fo.get_input() == 2)
			{
				drink dd(60,80,100);
				dd.displayy();
				dd.drinks();

				system("CLS");
			}

		}
			system("CLS");
			bill b;
			b.displayy();

		store sto;
		sto.record();

			system("pause");
		}

		if (a == 1)
		{
		//	price pr;
		//int w=	pr.bprice;
			administrator ad("admin", 11);
			cout << " press 1 for set staff salaries\n press 2 for set staff duties\n press 3 to add new employee\n";
			cout << " press 4 to display record of employee\n press 5 to set prices of items\n";
		
			int i;

			cin >> i;
			if (i == 1)
			{
				ad.set_salaries();
			}
			else if (i == 2)
			{
				ad.set_duties();
			}

			else if (i == 3)
			{
				ad.add_employee();

			}
			else if (i == 4)
			{
				ad.display_employee();
			}
			else if (i == 5)
				ad.set_prices();

          
		}
	
	


		else if (a == -1)
		{

		}
		else
			cout << "�nvalid entry\n";

	}
}