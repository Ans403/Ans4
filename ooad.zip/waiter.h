#pragma once


#include"salary.h"
#include"working_time.h"

class waiter:public salary,public work
{
public:
	waiter(char*, long int,char*,int);
	waiter(int);
	waiter();
	int length(char*);
	void copy(char*&, char*);	
	void set_salary(long int);
	void set__time(char*);
	long int get_salary();
	char* get_working_time();
	void set_total(int);
	int get_total();
	~waiter();

private:
	
	int total_waiters;
	char* name;
	int id;

};
