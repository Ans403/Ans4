#include"working_time.h"



int work::length(char *arr)
{
	int i = 0;
	for (i; arr[i] != '\0'; i++)
	{
	}
	return i;
}

void work::copy(char *&arr, char *arr1)
{
	int n = 0;
	int l = length(arr1);
	arr = new char[l + 1];
	for (; n < l; n++)
	{
		arr[n] = arr1[n];
	}
	arr[l] = '\0';
}

work::work(char* t)
{
	copy(time, t);
}


void work::set_time(char* t)
{
	copy(time,t);
}

char* work::get_time()
{
	return time;
}

work::work()
{

}

work::~work()
{
}