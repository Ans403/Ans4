#pragma once
#include"prices.h"
#include"display.h"
#include"food_items.h"


class fast_food:public display
{
public:
	price prices;

	fast_food(int = 0, int = 0, int = 0, int = 0, int = 0);

	void displayy();
	void fast();
	~fast_food();

private:
	int input;

};

