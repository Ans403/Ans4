#include"chef.h"

int chef::length(char *arr)
{
	int i = 0;
	for (i; arr[i] != '\0'; i++)
	{
	}
	return i;
}

void chef::copy(char *&arr, char *arr1)
{
	int n = 0;
	int l = length(arr1);
	arr = new char[l + 1];
	for (; n < l; n++)
	{
		arr[n] = arr1[n];
	}
	arr[l] = '\0';
}

chef::chef()
{
	no_of_chef = 0;
	
}



chef::chef(char* wor_t, long int sa, char* n, int id_) : sal(sa), wor(wor_t), person(n,id_)
{
	
}

void chef::set_salary(long int sala)

{
	sal.set_sal(sala);
}

void chef::set_time(char* t)
{
	wor.set_time(t);
}

long int chef::get_salary()
{
	return sal.get_sal();
}

char* chef::get_working_time()
{
	return wor.get_time();
}

int chef::get_no_of_chef()
{
	return no_of_chef;
}
void chef::set_no_of_chef(int no)

{
	no_of_chef = no;

}
chef::~chef()
{
	delete name;
}