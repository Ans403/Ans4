#pragma once
#include"display.h"
#include"prices.h"

class drink
{
public:
	drink(int = 0, int = 0, int = 0);
	void displayy();
	void drinks();

	~drink();

private:
	price pr;


};
