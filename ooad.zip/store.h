#pragma once
#include"bill.h"

class store:public bill
{
public:
	store();
	~store();
	void record();

private:

};

