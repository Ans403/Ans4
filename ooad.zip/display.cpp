#include"display.h"

display::display()
{
}

display::~display()
{
}