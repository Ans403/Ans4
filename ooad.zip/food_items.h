#pragma once

#include"display.h"
class foods:public display
{
public:
	foods();
	~foods();
	void displayy();
    int get_input();


private:
	
	 int input;
     

};

