#pragma once 

class display
{
public:
	display();
	~display();
    virtual void displayy() = 0;
private:

};

