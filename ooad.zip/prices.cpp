#include"prices.h"

#include<iostream>

using namespace std;
int price::bprice =0;
int price::pprice = 0;
int price::sprice = 0;
int price::sanprice = 0;
int price::fprice = 0;
long int price::total = 0;
int price::cdprice = 0;
int price::cprice = 0;
int price::wprice = 0;

price::price()
{

}

price::price(int b, int p, int s, int san, int f)
{
	bprice = b;
	pprice = p;
	sprice = s;
	sanprice = san;
	fprice = f;
	
	total = 0;

}
price::price(int w, int cd, int c)
{
	wprice = w;
	cprice = c;
	cdprice = cd;
}

 void price::set_bp(int b)
{
   bprice = b;
}

void price::set_pp(int p)
{
	pprice = p;
}

void price::set_sp(int s)
{
	sprice = s;
}
void price::set_sanp(int san)
{
	sanprice = san;
}

void price::set_fp(int f)
{

	fprice = f;
}

void price::set_wp(int w)
{

	wprice = w;
}

void price::set_cdp(int cd)
{

	cdprice = cd;
}

void price::set_cp(int c)
{

	cprice = c;
}



int price::get_bp()
{
	return bprice;
}

int price::get_pp()
{
	return pprice;
}

int price::get_sp()
{
	return sprice;
}
int price::get_sanp()
{
	return sanprice;
}
int price::get_fp()
{
	return fprice;
}

int price::get_wp()
{
	return wprice;
}

int price::get_cdp()
{
	return cdprice;
}

int price::get_cp()
{
	return cprice;
}

int price::get_total()
{
	return total;
}
void price::set_total(int t)
{
	total = t;
}
price::~price()
{
}