#include"person.h"

int person::_length(char *arr)
{
	int i = 0;
	for (i; arr[i] != '\0'; i++)
	{
	}
	return i;
}

void person::copy(char *&arr, char *arr1)
{
	int n = 0;
	int l = _length(arr1);
	arr = new char[l + 1];
	for (; n < l; n++)
	{
		arr[n] = arr1[n];
	}
	arr[l] = '\0';
}

person::person()
{

}

person::person(char* n, int id_)
{
	copy(name, n);
	
	id = id_;
}

int person::get_id()
{
	return id;
}
char* person::get_name()
{
	return name;
}


void person::set_id(int i)
{
	id = i;
}

void person::set_name(char* n)
{
	copy(name, n);
}


person::~person()
{
	delete name;
	
}