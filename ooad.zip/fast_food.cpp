#include"fast_foods.h"

#include<iostream>
#include<fstream>

using namespace std;

fast_food::fast_food(int b, int p, int s, int san, int f) :prices(b,p,s,san,f)

{
	input = 0;
}


void fast_food::displayy()
{
	cout << " press 1 for burger\n press 2 for pizza\n press 3 for sandwitch\n press 4 for fries\n press 5 for shawarma\n";
	cout << " enter -1 to exit\n";
}

void fast_food::fast()
{
	ofstream fout;
	fout.open("bil.txt");
	ifstream fin;
	fin.open("prices.txt");
	int t=0;

	while (input != -1)
	{
		cin >> input;
		int p = 0;
		switch (input)
		{
		case 1:
			p = prices.get_bp();
			cout << "price:" << p << endl;
			fout << "burger\t\t" << p << endl;

			break;

		case 2:
			p = prices.get_pp();
			cout << "price:" << p << endl;
			fout << "pizza\t\t" << p << endl;
			
			break;
		case 3:
			p = prices.get_sanp();
			cout << "price:" << p << endl;
			fout << "sandwitch\t" << p << endl;
			
			break;

		case 4:
			p = prices.get_fp();
			cout << "price:" << p << endl;
			fout << "fries\t\t" << p << endl;
			
			break;

		case 5:
			p = prices.get_sp();
			cout << "price:" << p << endl;
			fout << "shawarma\t" << p << endl;
			
			break;
		case -1:
			break;

		default:
			cout << "invalid input\n";
			break;
		}
		
			//t= prices.get_total();
			prices.set_total(0);

			t= t + p;
		


	}
	cout << "Total:" << t << endl;
	fout << "Total:" << t<<endl;
	prices.set_total(t);

}

fast_food::~fast_food()
{
}