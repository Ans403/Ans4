#include"food_items.h"

#include<iostream>
#include<fstream>

using namespace std;

foods::foods()
{
	input = 0;
}

foods::~foods()
{
}

void foods::displayy()
{
	cout << " press 1 for fast food\n press 2 for drinks\n press -1 to exit\n";
	cin >> input;

	
}


int foods::get_input()
{
	return input ;
}