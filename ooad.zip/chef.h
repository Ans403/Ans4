#pragma once 
#include"working_time.h"
#include"salary.h"
#include"person.h"


class chef:public person
{
public:
	salary sal;
	work wor;
	chef(char*,long int,char*,int);
	chef();
	int length(char*);
	void copy(char*&, char*);
	void set_salary(long int);
	void set_time(char*);
	long int get_salary();
	char* get_working_time();
	void set_no_of_chef(int);
	int get_no_of_chef();
	~chef();
   
private:
	
	int no_of_chef;
	char* name;
	int id;
};

