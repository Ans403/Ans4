#pragma once

class price
{
public:
	price();
	price(int,int,int,int,int);
	price(int, int, int);
	static void  set_bp(int);
	static void set_pp(int);
	static void set_sp(int);
	static void set_sanp(int);
	static void set_fp(int);
	
	static void set_wp(int);
	static void set_cp(int);
	static void set_cdp(int);

     static int get_bp();
	static int get_pp();
	static int get_sp();
	static int get_sanp();
	static int get_fp();
	
	static int get_wp();
	static int get_cp();
	static int get_cdp();

	static int get_total();
	static void set_total(int);

	~price();

private:
	
	static long int total;
    
	static int sprice;
	static int sanprice;
	static int fprice;
   static int bprice;
    static int pprice;
	static int wprice;
	static int cprice;
	static int cdprice;
};

