#pragma once 

#include"display.h"



class bill:public display
{
public:
	bill();
	~bill();
	void displayy();


private:

};


