#include"bill.h"

#include<iostream>
#include<fstream>
using namespace std;

bill::bill()
{
}

bill::~bill()
{
}

void bill::displayy()
{
	cout << "items\t\tprices\n";
	ifstream fin;
	fin.open("bil.txt");
	char a[20];
		
	while (!fin.eof())
	{
		fin.getline(a, 20);
		cout << a << endl;
	}

	
	


}
