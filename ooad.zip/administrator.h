#pragma once 
#include"person.h"
#include"prices.h"
#include"chef.h"
#include"waiter.h"



class administrator:public person
{
public:
	chef che;
	waiter wai;
	price pri;
	administrator(char*,int);
	administrator();
	void set_salaries();
	void set_duties();
	void add_employee();
	int length(char*);
	void set_salary(long int,char*);
	void set_time(char*,char*);
	void display_employee();
	void set_prices();
	int getb_price();
	int getp_price();
	int gets_price();
	int getsan_price();
	int getf_price();


	
	~administrator();

private:
	
	char* name;
	int id;

};

