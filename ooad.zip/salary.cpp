#include"salary.h"

salary::salary(long int s)
{
	sal = s;
}

long int  salary::get_sal()
{
	return sal;
}

void salary::set_sal(long int sa)
{
	sal = sa;
}

salary::~salary()
{
}