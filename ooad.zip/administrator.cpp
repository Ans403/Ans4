#include"administrator.h"
#include<fstream>
#include<iostream>

using namespace std;

administrator::administrator(char* n, int id_) :person(n,id_)
{
}

administrator::administrator()
{

}

int administrator::length(char *arr)
{
	int i = 0;
	for (i; arr[i] != '\0'; i++)
	{
	}
	return i;
}




administrator::~administrator()
{
	delete name;
}

void administrator::set_salary(long int s,char* file)
{
	//if (che.get_no_of_chef() != 0)
	{

		che.set_salary(s);
		cout << "enter name of chef or waiter whose salary you want to set \n";
		int x = 0;
		char* n = new char;
		char* l = new char;
		cin >> n;
		ifstream fin;
		fin.open(file);
		char a[20][20];
		int b[20];
		int r = 0;
		int j = 0;
		while (!fin.eof())
		{



			fin >> a[r];
			r++;
			fin >> a[r];
			r++;
			fin >> b[j];
			j++;
			fin >> a[r];

			r++;
		}
		fin.close();
		ifstream in;
		in.open(file);
		int c = 0;
		int ll = length(n);
		int l2 = ll;
		while (!in.eof())
		{
			c = 0;
			in.getline(l, 20);

			for (int i = 0; i <ll; i++)
			{

				if (l[i] == n[i])
				{
					l2--;
				}
				else
				{
					c++;
					break;
				}
			}
			if (c != 0)
			{
				l2 = ll;
				x++;
			}
			else if (l2 == 0)
			{
				break;
			}


		}
		in.close();

		b[x] = s;


		int e = r;
		int t = 0;
		ofstream fout;
		fout.open(file);

		for (int i = 0; i < e; i++)
		{
			fout << a[i] << "\t";
			i++;
			fout << a[i] << "\t";
			i++;
			fout << b[t] << "\t";
			t++;
			fout << a[i];
            
			if (i != e-1)
				fout << endl;

		}

		fout.close();

	}
	//	else
	//	cout << "there is no chef\n";
}





void administrator::set_salaries()
{
	
	cout << "press 1 to set chef salary\n press 2 to set waiter salary\n";
	int c;
	cin >> c;
	cout << "enter salary:";
	long int s;
	cin >> s;
	if (c == 1)
	{
		
		set_salary(s, "chef.txt");
		
	
	}
	else if (c == 2)
	{
		set_salary(s, "waiter.txt");
	}
	else
		cout << "invalid entry\n";

}

void administrator::set_time(char* t, char* file)
{
	wai.set_time(t);

	cout << "enter name of waiter whose salary you want to set \n";
	int x = 0;
	char* n = new char;
	char* l = new char;
	cin >> n;
	ifstream fin;
	fin.open(file);
	char a[20][20];
	char b[20][10];
	int r = 0;
	int j = 0;
	while (!fin.eof())
	{



		fin >> a[r];
		r++;
		fin >> a[r];
		r++;
		fin >> a[r];
		r++;
		fin >> b[j];
		j++;

	}
	fin.close();
	ifstream in;
	in.open(file);
	int c = 0;
	int ll = length(n);
	int l2 = ll;
	while (!in.eof())
	{
		c = 0;
		in.getline(l, 20);

		for (int i = 0; i <ll; i++)
		{

			if (l[i] == n[i])
			{
				l2--;
			}
			else
			{
				c++;
				break;
			}
		}
		if (c != 0)
		{
			l2 = ll;
			x++;
		}
		else if (l2 == 0)
		{
			break;
		}
	

	}
	in.close();
	int l3 = length(t);
	for (int i = 0; i < l3; i++)
	{
		b[x][i] = t[i];
	}

	int e = r;
	int s = 0;
	ofstream fout;
	fout.open(file);

	for (int i = 0; i < e; i++)
	{
		fout << a[i] << "\t";
		i++;
		fout << a[i] << "\t";
		i++;
		fout << a[i] << "\t";

		fout << b[s];
		s++;
		if (i != e - 1)
			fout << endl;

	}
	fout.close();
}


void administrator::set_duties()
{
	cout << "press 1 to set waiter duties\npress 2 to set chef duties\n";
	char *s;
	int c;
	s = new char[20];
	cin >> c;
	cout << "enter working houres\n";


	cin >> s;


	if (c == 1)

	{
		set_time(s, "waiter.txt");

	}

	else if (c == 2)
		set_time(s, "chef.txt");
	else
		cout << "invalid entry\n";
}


void administrator::add_employee()
{
	cout << "1 add employee as a chef\n2 add employee as a waiter\n";
	int x;
	cin >> x;
	char* tim;
	long int sal;
	char* nam;
	int _id;
	cout << "enter name\nenter id\nenter salary\nenter woring time\n";
	tim = new char[20];
	nam = new char[20];
	cin >> nam;

	cin >> _id;
	cin >> sal;
	cin >> tim;
	int y;
	if (x == 1)
	{
		ofstream fout;
		fout.open("chef.txt",ios::app);
		//chef New(tim, sal, nam, _id);
		y = che.get_no_of_chef();
		y++;
		che.set_no_of_chef(y);
	//	fout << y<<endl;
		fout << endl << nam << "\t" << _id << "\t" << sal << "\t" << tim;

		fout.close();
	}
	else if (x == 2)
	{
		ofstream out;
		out.open("waiter.txt", ios::app);
		//int x = wai.get_total();
		out << endl << nam << "\t" << _id << "\t" << sal << "\t" << tim;
		out.close();
		y = wai.get_total();
		y++;
		wai.set_total(y);
	}
}

void administrator::display_employee()
{
	cout << " press 1 for chef record\n press 2 for waiter record\n";
	int a = 0;
	cin >> a;
	if (a == 1)
	{
		ifstream fin;
		fin.open("chef.txt");
		char a[20][20];
		int i = 0;
		while (!fin.eof())
		{
			fin.getline (a[i],20);
			cout << a[i] << "\n";
			i++;
			cout << endl;
		}
		fin.close();
	}
	else if (a == 2)
	{
		ifstream fin;
		fin.open("waiter.txt");
		char a[20][20];
		int i = 0;
		while (!fin.eof())
		{
			fin.getline(a[i], 20);
			cout << a[i] << "\n";
			i++;
			cout << endl;
		}
		fin.close();
	}
	else
		cout << "invalid entry\n";
}

void administrator::set_prices()
{
	cout << " press 1 set burger price\n press 2 to set pizza price\n press 3 to set shwarma price\n press 4 to set sandwithch price\n";
	cout << " press 5 to set fires price\n press press 6 to set water price\n press 6 to set cold drink price\n press 8 to set coffee price\n";
	int c = 0,p=0;
	
	while (c != -1)
	{
		cin >> c;
		if (c != -1)
		{
			cout << " enter price\n";
				cin >> p;
		}
		if (c == 1)
		{

			pri.set_bp(p);
			
		}
		else if (c == 2)
		{
			
			pri.set_pp(p);
		}
		else if (c == 3)
		{
			
			pri.set_sp(p);
		}
		else if (c == 4)
		{
			pri.set_sanp(p);
		}
		else if (c == 5)
		{
			
			pri.set_fp(p);
		}
		else if (c == 6)
		{
			pri.set_wp(p);
		}
		else if (c == 7)
			pri.set_cp(p);
		else if (c == 8)
			pri.set_cdp(p);
		else if (c == -1)
		{
		}
		else
			cout << "invalid entry\n";
	}
}



int administrator::getb_price()
{
	return pri.get_bp();
}
int administrator::getp_price()
{
	return pri.get_pp();
}

int administrator::gets_price()
{
	return pri.get_sp();
}
int administrator::getsan_price()
{
	return pri.get_sanp();
}

int administrator::getf_price()
{
	return pri.get_fp();

}
